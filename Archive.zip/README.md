# CilasPal4.0
Grain Size Digitizer

Latest and most reliable update!

Simply download the code or clone the repository. 

To setup, open a terminal or command prompt window, cd into the code directory and run 'python CilasPalSetup.py'. This installs all necessary packages.

To run CilasPal, just run 'python CilasPal.py'

- Debug mode runs a test file (tests/testfile.pdf) with verbose output to catch indexing errors or other issues.
- Excel file output is the same directory as the input .pdf file
